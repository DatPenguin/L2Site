Project name :
FindMySchool

Authors :
Matteo STAIANO
Mathieu HANNOUN

Online version :
http://findmyschool.webutu.com/

Intranet version :
http://10.40.128.22/~mstaiano/L2Site

Repository :
http://github.com/DatPenguin/L2Site

Licence :
GNU GPL